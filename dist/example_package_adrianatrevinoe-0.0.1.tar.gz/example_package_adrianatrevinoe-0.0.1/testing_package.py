from example_package_adrianatrevinoe import example
example.add_one(2)
