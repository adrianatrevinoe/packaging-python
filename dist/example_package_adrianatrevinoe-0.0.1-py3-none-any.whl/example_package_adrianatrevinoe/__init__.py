[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

# with setuptools

# [build-system]
# requires = ["setuptools>=61.0"]
# build-backend = "setuptools.build_meta"
